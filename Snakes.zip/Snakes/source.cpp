#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <ctime>
#include <cstdlib>
using namespace std;

const int RANDFROM = 2;
const int RANDTO = 12;
//vector<char> letterLibrary; // legend of valid characters
//vector<char> activeFile; // file being modified
//vector<int> secretKeys;
vector<char> testVec;

/**
Returns a random number from RANFROM to RANDTO.

@return int
*/
int getRand();
/**
Reads the first line of a text file to the specified vector.

@param string Name of file to read.
@param vector<char> The vector to store the line of text.
*/
void readToVector(string, vector<char>&);

/**
Converts a char vector to a new text file.

@param string Name of the new file.
@param vector<char> The vector that will be saved.
*/
void createFile(string, vector<char>&);

int main(int argc, char* args[]) { ////////////////////////////////////////////////////////////////////////////////////////////////////////

  srand(time(0));
  for (int i = 0; i < 10; i++) {
    cout << getRand() << endl;
  }

  /*
  testVec.push_back('?');
  for (int i = 0; i < 26; i++) {
    testVec.push_back(char(97 + i));
  }

  cout << "Saving changes to file... ";
  ofstream outputStream;
  outputStream.open("test.txt");

  if (outputStream.fail()) { cout << "\nError opening file.\n"; exit(1); }

  for (int n = 0; n < testVec.size(); n++){
    outputStream << testVec[n];
  }
  cout << "file saved successfully.\n";
  outputStream.close();
  */
	return 0;
} ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Returns a random number from RANDFROM to RANDTO.
int getRand() {
	return ((rand() % RANDTO) + RANDFROM);
}

/*
// Reads the first line of a text file to the specified vector.
void readToVector(string fileName, vector<char>& charV) {
	cout << "Reading file... \n";
	ifstream inputStream(fileName);

	if (inputStream.fail()) { cout << "Error opening file.\n"; exit(1); }

	string line;
  getline(inputStream, line);
	cout << "Read file contains '" << line << "'\n";

	std::copy(line.begin(), line.end(), std::back_inserter(charV));

	cout << "File successfully read and copied to memory, containing " << activeFile.size() << " characters.\n";
  inputStream.close();
}
*/
/*
// Converts a char vector to a new text file.
void createFile(string fileName, vector<char>& charV) {
	cout << "Saving changes to file... ";
	ofstream outputStream;
	outputStream.open(fileName);

	if (outputStream.fail()) { cout << "\nError opening file.\n"; exit(1); }

	for (int n = 0; n < charV.size(); n++){
		outputStream << charV[n];
	}
	cout << "file saved successfully.\n";
	outputStream.close();
}
*/
