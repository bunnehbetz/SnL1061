/**
	41646.201509-INFR-1100U-001
	Cryptosystem.cpp

	Purpose: Encrypts and decrypts the first line of a text file. Reads in only English
	characters (upper and lower case) and blank spaces. Outputs two text files: an
	encrypted/decrypted text file, and a secret keys file.

	.exe	-e	<encrypt_this>	<output_encrypted>	<secret_file>
	.exe	-d	<decrypt_this>	<output_decrypted>	<secret_file>
	args[]	 1       2                 3				 4
  
	@version 1.0
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <ctime>
using namespace std;

const int RANDFROM = 1;
const int RANDTO = 53;
vector<char> letterLibrary; // legend of valid characters
vector<char> activeFile; // file being modified
vector<int> secretKeys;

/**
	Returns a random number from RANFROM to RANDTO.

	@return int
*/
int getRand();

/**
Creates the letterLibrary using the ASCII chart. This library contains '?', a-z, A-Z, and ' '.
*/
void createLibrary();

/**
Returns the index of the specified char from the letterLibrary.
*/
int search(char);

/**
	Generates the appropriate amount of secret keys and saves them to secretKeys.

	@param string Keys are generated for this file.
*/
void genKeys(string);

/**
	Reads the first line of a text file to the specified vector.

	@param string Name of file to read.
	@param vector<char> The vector to store the line of text.
*/
void readToVector(string, vector<char>&);

/**
	Reads a text file filled with numbers and separated by spaces into the specified vector.

	@param string Name of the file.
	@param vector<int> The vector to store the numbers.
*/
void readToVector(string, vector<int>&);

/**
	Converts a char vector to a new text file.

	@param string Name of the new file.
	@param vector<char> The vector that will be saved.
*/
void createFile(string, vector<char>&);

/**
	Converts an int vector to a new text file, with spaces between each int.

	@param string Name of the new file.
	@param vector<int> The vector that will be saved.
*/
void createFile(string, vector<int>&);

/**
Encrypts the activeFile.
*/
void encrypt();

/**
Decrypts the activeFile.
*/
void decrypt();

/**
Outputs the contents of a text file.

@param string Name of file.
*/
void finalOutput(string);

// ******************************************************************************************
// Controls operation of the program.
int main(int argc, char* args[]) {
	/*
		.exe	-e	<encrypt_this>	<output_encrypted>	<secret_file>
		.exe	-d	<decrypt_this>	<output_decrypted>	<secret_file>
		args[]	 1       2                 3				 4
	*/
	if (!args[1] || !args[2] || !args[3] || !args[4]) { cout << "ERROR: Please provide sufficient parameters.\n"; exit(2); }

	createLibrary();

	string arg = args[1];

	if (arg == "-e") {
		cout << "-------------------------Encryption selected--------------------------\n";
		readToVector(args[2], activeFile);
		genKeys(args[4]);
		encrypt();
	}
	else if (arg == "-d") {
		cout << "-------------------------Decryption selected--------------------------\n";
		readToVector(args[2], activeFile);
		readToVector(args[4], secretKeys);
		decrypt();
	}

	createFile(args[3], activeFile);
	finalOutput(args[3]);
	cout << "----------------------------------------------------------------------\n";
}
// ******************************************************************************************
// ******************************************************************************************

// Returns a random number from RANDFROM to RANDTO.
int getRand() {
	return ((rand() % RANDTO) + RANDFROM);
}

// Creates the letterLibrary using the ASCII chart. This library contains '?', a-z, A-Z, and ' '.
void createLibrary() {
	letterLibrary.push_back('?');

	for (int n = 0; n < 26; n++){
		letterLibrary.push_back(char(97 + n));

	}
	for (int n = 0; n < 26; n++){
		letterLibrary.push_back(char(65 + n));
	}

	letterLibrary.push_back(' ');
}

// Returns the index of the specified char from the letterLibrary.
int search(char c) {
	for (int i = 0; i < letterLibrary.size(); i++) {
		if (c == letterLibrary[i]) return i;
	}
}

// Generates the appropriate amount of secret keys and saves them to secretKeys.
void genKeys(string fileName) {
	cout << "Generating secret keys... ";
	srand(time(0));
	for (int i = 0; i < activeFile.size(); i++) {
		secretKeys.push_back(getRand());
	}
	cout << "successfully generated " << secretKeys.size() << " keys.\n";
	createFile(fileName, secretKeys);
}

// Reads the first line of a text file to the specified vector.
void readToVector(string fileName, vector<char>& charV) {
	cout << "Reading file... \n";
	ifstream inputStream(fileName);

	if (inputStream.fail()) { cout << "Error opening file.\n"; exit(1); }

	string line;
	getline(inputStream, line);
	cout << "Read file contains '" << line << "'\n";

	std::copy(line.begin(), line.end(), std::back_inserter(charV));

	cout << "File successfully read and copied to memory, containing " << activeFile.size() << " characters.\n";
	inputStream.close();
}

// Reads a text file filled with numbers and separated by spaces into the specified vector.
void readToVector(string fileName, vector<int>& intV) {
	cout << "Reading keys... ";
	ifstream inputStream(fileName);

	if (inputStream.fail()) { cout << "\nError opening file.\n"; exit(1); }

	int current;
	while (inputStream >> current) {
		intV.push_back(current);
	}
	cout << secretKeys.size() << " keys successfully read and copied into memory.\n";
	inputStream.close();
}

// Converts a char vector to a new text file.
void createFile(string fileName, vector<char>& charV) {
	cout << "Saving changes to file... ";
	ofstream outputStream;
	outputStream.open(fileName);

	if (outputStream.fail()) { cout << "\nError opening file.\n"; exit(1); }

	for (int n = 0; n < charV.size(); n++){
		outputStream << charV[n];
	}
	cout << "file saved successfully.\n";
	outputStream.close();
}

// Converts an int vector to a new text file, with spaces between each int.
void createFile(string fileName, vector<int>& intV) {
	cout << "Saving secret keys to file... ";
	ofstream outputStream;
	outputStream.open(fileName);

	if (outputStream.fail()) { cout << "\nError opening file.\n"; exit(1); }

	for (int n = 0; n < intV.size(); n++){
		outputStream << intV[n] << ' ';
	}
	cout << "secret keys saved succesfully.\n";
	outputStream.close();
}

// Encrypts the activeFile.
void encrypt() {
	cout << "Encrypting file... ";
	int C;
	for (int i = 0; i < activeFile.size(); i++) {
		C = (search(activeFile[i]) + secretKeys[i]);
		if (C > 53) C -= 53;
		activeFile[i] = letterLibrary[C];
	}
	cout << "encryption complete. \n";
}

// Decrypts the activeFile.
void decrypt(){
	cout << "Decrypting file... ";

	if (activeFile.size() > secretKeys.size()) {
		cout << "\nERROR: The number of secret keys does not match the number of characters in the file you wish to decrypt.\n"
			<< "Please provide a sufficient number of secret keys.\n";
		exit(3);
	}

	int p;
	for (int i = 0; i < activeFile.size(); i++) {
		p = ((search(activeFile[i])) - secretKeys[i]);
		if (p < 1) p += 53;
		activeFile[i] = letterLibrary[p];
	}
	cout << "decryption complete.\n";
}

// Outputs the contents of a text file.
void finalOutput(string fileName) {
	ifstream inputStream(fileName);

	if (inputStream.fail()) { cout << "Error opening saved file. \n"; exit(1); }

	string line;
	getline(inputStream, line);
	cout << "Saved file contains '" << line << "'\n";
	inputStream.close();
}
