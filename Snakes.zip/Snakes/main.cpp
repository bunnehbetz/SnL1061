//main.cpp
#include "Board.h"
#include "Player.h"
#include <limits> // cin.ignore
#include <vector>
using std::cout;

Board b;
vector<Player> players;
bool noWinner = true;

int startMenu();
void cinRe();
void newGame();
void playGame();

int main() { ///////////////////////////////////////////////////////////////////
  if(startMenu() == 1) {
    newGame();
  } else { //Continue Game
  }
  playGame();
  return 0;
} //////////////////////////////////////////////////////////////////////////////

int startMenu() {
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
       << "Welcome to Snakes and Ladders!\n"
       << "1. New Game \n"
       << "2. Continue \n"
       << "3. Exit \n";

  int choice = 0;

  SELECTOPTION:cout << "Please select one of the options: ";

  cin >> choice;

  switch(choice) {
    case 1:
      cinRe();
      return 1;
    case 2:
      cinRe();
      return 2;
    case 3:
      cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
      cout << "Exiting.. exited.\n";
      cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
      exit(1);
    default:
      cout << "Error. ";
      cinRe();
      goto SELECTOPTION;
      break;
  }
}

void cinRe() {
  cin.clear();
  cin.ignore(numeric_limits<streamsize>::max(),'\n');
}

void newGame() {
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
       << "~~~~~~New Game Selected~~~~~~\n"
       << "How many players? ";

  int choice = 0;

  RETRY:cin >> choice;

  if (cin.fail()) {
    cinRe();
    cout << "Error. Please input a number. ";
    goto RETRY;
  } else if (choice > 0) {
    for (int i = 1; i <= choice; i++) {
      string name;
      cout << "What is player " << i << "'s name? ";
      cin >> name;
      Player p(name);
      players.push_back(p);
      players[0].setTurn(true);
    }
  } else {
    cout << "Error. Please input a positive integer.";
    cinRe();
    goto RETRY;
  }
  cinRe();
}


void playGame() {
  do {
    for(int i = 0; i < players.size();i++) { // 1
      if(players[i].isTurn()) { // 2
        cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
             << "It's " << players[i].getName() << "'s turn! \n"
             << players[i].getName() << " is on square " << players[i].getPos() << ".\n"
             << "\tPress ENTER to roll. ";
        cin.get();

        int move = b.rollDice();
        cout << players[i].getName() << " rolled: " << move << endl;

        players[i].setPos(move);
        cout << players[i].getName() << " is now on square " << players[i].getPos() << ".\n";

        if(b.getValue(players[i].getPos()) != 0) {
          if (b.getValue(players[i].getPos()) > 0) {
            cout << "But wait! This is a ladder!\n";
            players[i].climb(b.getValue(players[i].getPos()));
            cout << players[i].getName() << " jumps to square ";
          } else {
            cout << "Uh oh. You have landed on a snake. \n";
            players[i].slide(b.getValue(players[i].getPos()));
            cout << players[i].getName() << " fell to square ";
          }
          cout << players[i].getPos() << ".\n";
        }

        if(players[i].isWinner()) {
          noWinner = false;
          cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
               << "And the winner is.. " << players[i].getName() << "!\nCongratulations!\n";
        }

        players[i].setTurn(false);
        if (i != players.size() - 1) {
          players[i+1].setTurn(true);
        } else {
          players[0].setTurn(true);
        }
      } // 2
    } // 1
  } while (noWinner);
  cinRe();
}
