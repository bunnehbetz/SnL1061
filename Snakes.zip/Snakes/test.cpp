#include <ctime>
#include <cstdlib>
#include <iostream>
using namespace std;

const int RANDFROM = 2;
const int RANDTO = 11;

int rollDice() {
  return ((rand() % RANDTO) + RANDFROM);
}

int main() {
  srand(time(0));

  for (int i = 0; i < 30; i++) {
    cout << rollDice() << endl;
  }

  return 0;
}

/*
void playGame() {
  players[0].setTurn(true);
  //for(int i = 0; i < players.size();i++) {
  int test;
  do {
    test++;
    cout << test << endl;
    if(players[0].isTurn()) {

      int move = b.rollDice();
      cout << "Rolled: " << move << endl;

      players[0].setPos(move);
      cout << "INI " << players[0];

      if(b.getValue(players[0].getPos()) != 0) {
        cout << "PRINT " << b.getValue(players[0].getPos()) << endl;
        if (b.getValue(players[0].getPos()) > 0) {
          cout << "Ladder \n";
          players[0].climb(b.getValue(players[0].getPos()));
          cout << players[0];
        } else {
          cout << "Snake \n";
          players[0].slide(b.getValue(players[0].getPos()));
          cout << players[0];
        }
      }

      if(players[0].isWinner()) {
        noWinner = false;
      }
    }
  } while (noWinner);
  //}
  cout << players[0];
}
