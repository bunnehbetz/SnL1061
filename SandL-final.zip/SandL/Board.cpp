//Board.cpp
#include "Board.h"

Board::Board() {
  srand(time(0));

  for(int i = 0; i < SIZE; i++) {
    board[i] = 0;
  }

  board[17] = -7; // 7
  board[54] = -34; //34
  board[62] = -19; //19
  board[64] = -60; //60
  board[87] = -24; //24
  board[93] = -73; //73
  board[95] = -75; //75
  board[99] = -78; //78

  board[4] = 14; //14
  board[9] = 31; //31
  board[20] = 38; //38
  board[28] = 84; //84
  board[40] = 59; //59
  board[51] = 67; //67
  board[63] = 81; //81
  board[71] = 91; //91
}

int Board::getValue(int pos) {
  return board[pos];
}

bool Board::isSnake(int pos) {
  if (board[pos] < 0) {
    return true;
  }
  return false;
}

bool Board::isLadder(int pos) {
  if (board[pos] > 0) {
    return true;
  }
  return false;
}

int Board::rollDice() {
  return ((rand() % RANDTO) + RANDFROM);
}
