#ifndef TT_H
#define TT_H


#include <iostream>
#include <string>
#include <sstream>
#include <ctime>
#include <cstdlib>
//#include "Board.h"
#include "Player.h"
#include <vector>
using namespace std;

class tt: public Player{
private:
  static const int board_size = 10;
  int temp1[100];
  int temp2[100];
  int temp3[100];
  int counter;
  string conversion;
  string board[board_size][board_size];
  int position_id;
  int position[100];
  int acdc;
  int z;

public:

  int ascii;
  void displayBoard(string b[][board_size]);
  void ourpositionfunc();
  void loop();
  int pl;
  int sz;
  int iterator;
  tt();
};
#endif
