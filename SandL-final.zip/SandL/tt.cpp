#include "tt.h"

////////////////////////////////////////////////////////////////////////////


// int main() {
//tt testing;
//
// for (int test = 0; test < 100; test ++){ // while (Player::isWinner = false){
//   //loop here to cycle through the players
//   b.ourpositionfunc();
//
//   //cout << "\033[2J\033[1;1H";
//   std::system("clear");
//   //}
//   }
// }



////////////////////////////////////////////////////////////////////////////


void tt::displayBoard(string b[][board_size]) {
  //cout << "Tic-tac-toe board:" << endl << endl;
  cout <<"\t""\t""\t""\t"<<"IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII" << endl;
  cout <<"\t""\t""\t""\t"<<"IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII SNAKES AND LADDERS IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII" << endl;
  cout <<"\t""\t""\t""\t"<<"IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII" << endl;
  b[9][3] = "\033[1;31mSS\033[0m";
  b[8][3] = "\033[1;31mSS\033[0m";

  b[4][6] = "\033[1;32mSS\033[0m";
  b[6][6] = "\033[1;32mSS\033[0m";

  b[3][8] = "\033[1;33mSS\033[0m";
  b[8][1] = "\033[1;33mSS\033[0m";

  b[3][6] = "\033[1;34mSS\033[0m";
  b[4][0] = "\033[1;34mSS\033[0m";

  b[1][3] = "\033[1;35mSS\033[0m";
  b[7][6] = "\033[1;35mSS\033[0m";

  b[0][7] = "\033[1;36mSS\033[0m";
  b[2][7] = "\033[1;36mSS\033[0m";

  b[0][5] = "\033[1;37SS\033[0m";
  b[2][5] = "\033[1;37SS\033[0m";

  b[0][5] = "SS";
  b[2][5] = "SS";

  // LADDER /////////////

  b[9][6]="\033[1;31m╬╬\033[0m";
  b[8][6]="\033[1;31m╬╬\033[0m";

  b[9][1]="\033[1;32m╬╬\033[0m";
  b[6][9]="\033[1;32m╬╬\033[0m";

  b[8][0]="\033[1;33m╬╬\033[0m";
  b[6][2]="\033[1;33m╬╬\033[0m";

  b[7][2]="\033[1;34m╬╬\033[0m";
  b[1][6]="\033[1;34m╬╬\033[0m";

  b[6][0]="\033[1;35m╬╬\033[0m";
  b[4][1]="\033[1;35m╬╬\033[0m";

  b[4][9]="\033[1;36m╬╬\033[0m";
  b[3][3]="\033[1;36m╬╬\033[0m";

  b[3][7]="\033[1;37m╬╬\033[0m";
  b[1][9]="\033[1;37m╬╬\033[0m";

  b[2][9]="╬╬";
  b[0][9]="╬╬";



  for (int i=0; i< board_size; i++) {
    cout << "\t""\t""\t""\t"<< "IIII" << "\t";
      for (int j=0; j < board_size; j++) {
        cout << "|" <<b[i][j] <<" " << "|"<< "\t";
        if ( j == board_size-1) {
          cout << "IIII";
        }
      }

    cout << endl;
  }
  cout <<"\t""\t""\t""\t"<< "IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII" << endl;
  cout <<"\t""\t""\t""\t"<<"IIIIIIIIIIIIIIIIIIIIIIIIIIIII BY STEPH, RISH, BETTY AND RAMEET IIIIIIIIIIIIIIIIIIIIIIIIIIIII" << endl;
  cout <<"\t""\t""\t""\t"<<"IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII" << endl;
  cout << endl;
}

void tt::loop () {
  if (z == sz){
    z = 0;
    ascii = 34;
  }
  z++;
  ascii ++;
}



void tt::ourpositionfunc() {

  //if (checkWinnerASCII == 1){
    if (counter > 0){
    //for (int z=0;z<3; z++){
      loop();
      for (int l = 0; l <1;l++){
      temp3[z] = 101 - temp3[z];
      ostringstream convert;   // stream used for the conversion
      convert << temp3[z];      // insert the textual representation of 'Number' in the characters in the stream
      conversion = convert.str(); // set 'Result' to the contents of the stream

      board[temp1[z]][temp2[z]] = conversion;

      //cin.get(getPos) = position_id;  <-.
      //position_id = getPos(); //get position
      position_id = pl;
      //position_id = tt::posASCII;
      position_id = 101 - position_id;
      //call function here


      temp3[z] = position_id; //store a copy of position id in temp3
      int row = (position_id-1)/board_size; //position id converted to row and column
      int col = (position_id-1)%board_size;

      temp1[z] = row;
      temp2[z] = col;
      board[row][col] = ascii;

      //cout << pl << endl;
      ascii ++;
      displayBoard(board);
      //std::system("clear");
    }
    //}
  }
  if(counter ==0)  {
    //for (int z=0;z<3/*numofplayers*/; z++){
    loop();
      for (int l = 0; l <1;l++){

      //cout << "is it working? " << sz << endl;

      //cout <<"\t""\t""\t""\t"<< "where do u wanna go fam?: ";
      //position_id = getPos();
      position_id = pl;
      //position_id = posASCII; //get position
      position_id = 101 - position_id;
      temp3[z] = position_id; //store a copy of position id in
      int row = (position_id-1)/board_size; //position id converted to row and
      int col = (position_id-1)%board_size;
      temp1[z] = row;
      temp2[z] = col;
      board[row][col] = ascii;
      ascii++;
      //std::system("clear");
      displayBoard(board);
    }
    //}
    counter ++;
    }
  //}
}


tt::tt(): counter(0), position_id(100), ascii(34){
  //construct board
  for (int i=0; i< board_size; i++) {
    for (int j=0; j < board_size; j++) {
      stringstream ss;
      ss << position_id;
      board[i][j] = ss.str();
      position_id--;
    }
  }
}
