//main.cpp
#include "Board.h"
#include "Player.h"
#include "kbhit.h" // keypress >>> WARNING: g++ only
#include <limits> // cin.ignore
#include <fstream>
#include <sstream>
#include <cstdio> // remove file from system
using namespace std;

#define HIGHSCORES "hs.sbrr"
#define SAVES "saves.sbrr"

Board b;
vector<Player> players;
vector<string> slots;

void startMenu();
void exitGame();
void cinRe();
void clearData();

void newGame();
void playGame();
void playAgain();

void showHighscores();
void saveHighscores(int i, int score);

void showSaves();
void saveGame();
void openSaves(int i);
void saveSaves(string newSave, int keep);
bool slotDupe(string dupe);

int main() {
  startMenu();
  return 0;
}

void startMenu() {
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
       << "Welcome to Snakes and Ladders!\n"
       << "1. New Game \n"
       << "2. Continue \n"
       << "3. View Highscores \n"
       << "4. Exit \n";

  int choice = 0;

  SELECTOPTION:cout << "Please select one of the options: ";

  cin >> choice;

  switch(choice) {
    case 1:
      cinRe();
      newGame();
      break;
    case 2:
      cinRe();
      showSaves();
      break;
    case 3:
      cinRe();
      showHighscores();
      break;
    case 4:
      exitGame();
    default:
      cout << "Error. ";
      cinRe();
      goto SELECTOPTION;
      break;
  }
}

void exitGame() {
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
  cout << "Exiting.. exited.\n";
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
  exit(1);
}

void cinRe() {
  cin.clear();
  cin.ignore(numeric_limits<streamsize>::max(),'\n');
}

void clearData() {
  players.clear();
}

void newGame() {
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
       << "~~~~~~New Game Selected~~~~~~\n"
       << "How many players? ";

  int choice = 0;

  RETRY:cin >> choice;

  if (cin.fail()) {
    cinRe();
    cout << "Error. Please input a number. ";
    goto RETRY;
  } else if (choice > 0) {
    for (int i = 1; i <= choice; i++) {
      string name;
      cout << "What is player " << i << "'s name? ";
      cin >> name;
      Player p(name);
      players.push_back(p);
      players[0].setTurn(true);
    }
  } else {
    cout << "Error. Please input a positive integer.";
    cinRe();
    goto RETRY;
  }
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
       << "\tNOTE:\n"
       << "Press 's' to save the game at anytime!\n"
       << "Press ENTER to continue..";
  cin.get();
  cinRe();
  playGame();
}

void playGame() {
  int turns = 0;

  int ch;
  changemode(1);

  while(!kbhit()) {
    for(int i = 0; i < players.size();i++) { // 1
      if (i == 0) turns++;
      if(players[i].isTurn()) { // 2
        cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
             << "It's " << players[i].getName() << "'s turn! \n"
             << players[i].getName() << " is on square " << players[i].getPos() << ".\n"
             << "\tPress ENTER to roll. ";

        ch = getchar();
        if (ch == 's') {
          changemode(0);
          goto SAVE;
        }

        int move = b.rollDice();
        cout << endl << players[i].getName() << " rolled: " << move << endl;

        players[i].setPos(move);
        cout << players[i].getName() << " is now on square " << players[i].getPos() << ".\n";

        if(b.getValue(players[i].getPos()) != 0) {
          if (b.getValue(players[i].getPos()) > 0) {
            cout << "But wait! This is a ladder!\n";
            players[i].climb(b.getValue(players[i].getPos()));
            cout << players[i].getName() << " jumps to square ";
          } else {
            cout << "Uh oh. You have landed on a snake. \n";
            players[i].slide(b.getValue(players[i].getPos()));
            cout << players[i].getName() << " fell to square ";
          }
          cout << players[i].getPos() << ".\n";
        }

        if(players[i].isWinner()) {
          cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
               << "And the winner is.. " << players[i].getName() << "!\nCongratulations!\n";
          saveHighscores(i, turns);
          goto NEXT;
        }

        players[i].setTurn(false);
        if (i != players.size() - 1) {
          players[i+1].setTurn(true);
        } else {
          players[0].setTurn(true);
        }
      } // 2
    } // 1
  } // inf

  NEXT:
  changemode(0);
  cinRe();
  clearData();
  playAgain();

  SAVE:
  cout << "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
  saveGame();
  startMenu();
}

void playAgain() {
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
       << "Play again? (y/n) ";

  char choice = 0;

  SELECTOPTION:cout << "Please select one of the options: ";

  cin >> choice;

  switch(choice) {
    case 'y':
      cinRe();
      newGame();
      break;
    case 'n':
      cinRe();
      startMenu();
      break;
    default:
      cout << "Error. ";
      cinRe();
      goto SELECTOPTION;
      break;
  }
}

void showHighscores() {
  ifstream inputStream(HIGHSCORES);
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
       << "~~~~~~~~ HIGHSCORES ~~~~~~~~~\n"
       << "Name                    Turns\n"
       << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";

  char next;

  while(inputStream >> noskipws >> next) {
    cout << next;
  }
	inputStream.close();
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
  cinRe();
  startMenu();
}

void saveHighscores(int i, int score) {
  vector<char> highscores;
  ifstream inputStream(HIGHSCORES);
  char current;
  while(inputStream >> noskipws >> current) {
    highscores.push_back(current);
  }
	inputStream.close();

  string winner = players[i].getName();
  int nl = (12 - winner.length()) + 14;
  for (int i = 0; i < nl; i++) {
    winner = winner + " ";
  }
  std::copy(winner.begin(), winner.end(), std::back_inserter(highscores));
  highscores.push_back(' ');

  int one = score % 10; // yes I know this is ugly I'm sorry
  int two = (score / 10) % 10;
  int three = (score / 100) % 10;
  int four = (score / 1000) % 10;
  bool format = true;

  if (four != 0) { highscores.push_back(char(48 + four)); format = false; }
  if (three != 0) { highscores.push_back(char(48 + three)); format = false; }
  if (two != 0) { highscores.push_back(char(48 + two)); format = false; }
  if (format) highscores.push_back(' ');
  highscores.push_back(char(48 + one));

  highscores.push_back('\n');

  ofstream outputStream;
	outputStream.open(HIGHSCORES);

	for (int n = 0; n < highscores.size(); n++){
		outputStream << highscores[n];
	}
	outputStream.close();
}

void showSaves() {
  slots.clear();
  ifstream inputStream(SAVES);
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
       << "~~~~~~~~ SAVE SLOTS ~~~~~~~~~\n";

  string line;
  while(inputStream >> line) {
    slots.push_back(line);
  }
  inputStream.close();

  if (slots.size() < 1) { cout << "No saved games.\n"; startMenu(); }

  for (int i = 1; i <= slots.size(); i++) {
    cout << "  " << i << ". " << slots[i - 1] << endl;
  }
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
       << "(Enter -1 to return to the main menu)\n";
  TRYAGAIN:
  cout << "Please choose a valid slot: ";
  int choice;
  cin >> choice;
  if ((choice > 0) && (choice <= slots.size())) openSaves(choice - 1);
  else if (choice == -1) startMenu();
  else { cinRe(); goto TRYAGAIN; }
}

void saveGame() {
  vector<char> saveslot;

  for(int i = 0; i < players.size(); i++) {
    string name = players[i].getName();
    std::copy(name.begin(), name.end(), std::back_inserter(saveslot));
    saveslot.push_back('\n');

    int pos = players[i].getPos();

    int one = pos % 10;
    int two = (pos / 10) % 10;

    if (two != 0) saveslot.push_back(char(48 + two));
    saveslot.push_back(char(48 + one));
    saveslot.push_back('\n');

    if (players[i].isTurn()) {
      saveslot.push_back('1');
    } else {
      saveslot.push_back('0');
    }
    saveslot.push_back('\n');
  }

RETRY:
  string newFile;
  cout << "Name of save (no spaces): ";
  cin >> newFile;
  newFile += ".sbrr";
  cinRe();
  if (slotDupe(newFile)) {
    cout << "Error: this file already exists.\n";
    goto RETRY;
  }
  saveSaves(newFile, -1);

  ofstream outputStream;
	outputStream.open(newFile.c_str());

	for (int n = 0; n < saveslot.size(); n++){
		outputStream << saveslot[n];
	}
	outputStream.close();

  clearData();
}

void openSaves(int ind) {
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
  vector<string> contents;
  ifstream inputStream(slots[ind].c_str());
  if (inputStream.fail()) {
    cout << "ERROR. " << slots[ind] << " not found.\n";
    cinRe();
    showSaves();
  }
  string line;
  while(inputStream >> line) {
    contents.push_back(line);
  }
  inputStream.close();

  int count = 0;

  Player p;
  for (int i = 0; i < contents.size(); i++) {
    int mod = (i + 1) % 3; // 3 lines per player
    if (mod == 1) { //name
      p.setName(contents[i]);
      players.push_back(p);
    } else if (mod == 2) { // pos
      stringstream ss(contents[i]);
      int pos;
      ss >> pos;
      players[count].setPos(pos);
    } else { // turn
      if (contents[i] == "1") {
        players[count].setTurn(true);
      }
      count++;
    }
  }
  saveSaves("", ind);
  cinRe();
  playGame();
}

void saveSaves(string newSave, int delThis) {
  slots.clear();
  ifstream inputStream(SAVES);
  string history;
  while(inputStream >> history) {
    slots.push_back(history);
  }
  inputStream.close();
  if (delThis == -1) slots.push_back(newSave.c_str());
  else {
    remove(slots[delThis].c_str());
    slots.erase(slots.begin()+delThis);
  }

  ofstream outputStream;
  outputStream.open(SAVES);
  for (int n = 0; n < slots.size(); n++){
    outputStream << slots[n] << endl;
  }
  outputStream.close();
}

bool slotDupe(string dupe) {
  slots.clear();
  ifstream inputStream(SAVES);
  string history;
  while(inputStream >> history) {
    slots.push_back(history);
  }
  inputStream.close();
  for (int i = 0; i < slots.size(); i++) {
    if (slots[i] == dupe) {
      slots.clear();
      return true;
    }
  }
  slots.clear();
  return false;
}
