CSCI 1061U (Winter 2016) Course Project
Title: Snakes and Ladders
Group number: 11
Group members:
    - Stephanie Phung, stephanie.phung1@uoit.net
    - Rameet Sekhon, rameet.sekhon@uoit.net
    - Betty Kwong, betty.kwong@uoit.net
    - Rishabh Patel, rishabh.patel@uoit.net
Comments:
  - Program only compiles in g++
