//Player.cpp
#include "Player.h"

Player::Player()
  : name("Player"), pos(0), turn(false), winner(false) {
    // deliberately empty
}

Player::Player(string thisName)
  : pos(0), turn(false), winner(false) {
    name = thisName;
}

void Player::setName(string newName) {
  name = newName;
}

string Player::getName() const {
  return name;
}

void Player::setPos(int rolled) {
  int check = rolled + pos;
  if (check <= 100) {
    pos += rolled;
  } else {
    cout << name << " goes forwards.. and then backwards.\n";
    check -= 100;
    pos = 100 - check;
  }
  if (pos == 100) setWinner(true);
}

void Player::slide(int downPos) {
  pos = abs(downPos);
}

void Player::climb(int upPos) {
  pos = upPos;
}

int Player::getPos() const {
  return pos;
}

bool Player::isTurn() const {
  return turn;
}

void Player::setTurn(bool flag) {
  turn = flag;
}

bool Player::isWinner() const {
  return winner;
}

void Player::setWinner(bool flag) {
  winner = flag;
}

ostream& operator<<(ostream& os, const Player& p) {
  os << p.name << " is at position " << p.pos << ".";
  if (p.isTurn()) os << " is turn\n";
  else os << " not turn\n";
  return os;
}
