//Board.h
#ifndef BOARD_H
#define BOARD_H

#include <vector>
#include <ctime> // time
#include <cstdlib> // rand
using std::vector;

const int RANDFROM = 2;
const int RANDTO = 11;
const int SIZE = 101;

class Board {
private:
  int board[SIZE];
public:
  Board();
  bool isSnake(int);
  bool isLadder(int);
  int rollDice();
  int getValue(int);
};

#endif
