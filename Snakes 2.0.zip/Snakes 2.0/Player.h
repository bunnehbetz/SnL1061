//Player.h
#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>
#include <string>
#include <cmath>
using namespace std;

class Player {
public:
  string name;
  int pos;
  bool turn;
  bool winner;
  void setWinner(bool);
  Player();
  Player(string);

  void setName(string);
  string getName() const;

  void setPos(int);
  void slide(int);
  void climb(int);
  int getPos() const;

  bool isTurn() const;
  void setTurn(bool);

  bool isWinner() const;

  friend ostream& operator<<(ostream&, const Player&);
};

#endif
